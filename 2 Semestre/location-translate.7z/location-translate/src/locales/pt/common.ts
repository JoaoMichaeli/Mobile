export default {
  "welcome": "Bem-vindo",
  "hello": "Olá {{name}}!",
  "buttons": {
    "save": "Salvar",
    "cancel": "Cancelar",
    "delete": "Excluir",
  },
  "messages": {
    "success": "Operação realizada com sucesso!",
    "error": "Ops! Algo deu errado."
  }
}